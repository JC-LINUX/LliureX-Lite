package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.15-1";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2025-06-09 12:47"
];

1;

